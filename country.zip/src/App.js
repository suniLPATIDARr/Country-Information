import React from 'react';
import logo from './logo.svg';
import './App.css';
import Country from "./components/Country"

function App() {
  return (
    <div className="App">
      <Country/>
    </div>
  );
}

export default App;
